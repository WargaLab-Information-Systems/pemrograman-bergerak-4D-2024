package com.example.modul3nebula

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class beranda : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beranda)

        val judulHotel = findViewById<TextView>(R.id.judulHotel)
        val textDeskrpisi = findViewById<TextView>(R.id.textDeskrpisi)
        val gambarHotel = findViewById<ImageView>(R.id.gambarHotel)
        val shareButton = findViewById<ImageView>(R.id.shareButton)

        shareButton.setOnClickListener {
            shareContent(judulHotel.text.toString(), textDeskrpisi.text.toString(), gambarHotel)
        }
    }

    private fun shareContent(judul: String, deskripsi: String, imageView: ImageView) {
        // Convert image to bitmap
        val drawable = imageView.drawable as BitmapDrawable
        val bitmap = drawable.bitmap

        // Save bitmap to cache directory
        val cachePath = File(cacheDir, "images")
        cachePath.mkdirs()
        val file = File(cachePath, "image.png")
        val fileOutputStream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
        fileOutputStream.close()

        // Get URI for file
        val contentUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

        // Create share intent
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "$judul\n\n$deskripsi")
            putExtra(Intent.EXTRA_STREAM, contentUri)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Start share intent
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }
}
