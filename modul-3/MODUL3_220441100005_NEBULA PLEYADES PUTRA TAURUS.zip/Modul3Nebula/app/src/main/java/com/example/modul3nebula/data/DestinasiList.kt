package com.example.modul3nebula

import com.example.modul3nebula.R

object DestinasiList {
    val LokasiDum = arrayListOf(
        LocationData(
            "Pantai Kuyon",
            "Desa Wisata Bahari Nglebeng di Kabupaten Trenggalek mempunyai produk wisata Pantai Kuyon. Pantai Kuyon memiliki keindahan pantai yang berbatasan dengan sawah yang menambah kecantikan pantai. Pantai Kuyon dapat dijadikan lokasi liburan di akhir pekan bersama teman-teman untuk refreshing.\n",
            "Trenggalek",
            R.drawable.kuyon
        ),
        LocationData(
            "Pantai Kebo",
            "Pantai Kebo Trenggalek memiliki spot yang cukup istimewa berupa rerumputan hijau luas dengan aksen aliran air bagaikan sungai dan beberapa ekor kerbau. Latar belakang pantai berupa bukit-bukit hijau yang mampu menambah alami pemandangan sekitar.\n",
            "Trenggalek",
            R.drawable.kebo
        ),
        LocationData(
            "Hutan Kota",
            "Wisata alam yang terletak ditengah kota yang mampu menarik perhatian warga dan hampir setiap hari ramai dikunjungi. Hutan Kota Trenggalek juga merupakan Hutan Kota yang terbesar di tingkat Kabupaten se-Provinsi Jawa Timur. Kawasan wisata ini menawarkan beragam pesona alam yang asri. Suasananya sangat sejuk dengan pepohonan rindang disekitarnya. Hutan yang terletak di Gunung Jaas, sebelah barat kota Trenggalek. Menyajikan hutan hijau di bukit dengan view kota Trenggalek yang bisa dilihat dari puncak Gunung Jaas.",
            "Trenggalek",
            R.drawable.huko
        )
    )

    val HotelDum = arrayListOf(
        HotelData(
            "Hayam Wuruk",
            20,
            4.9,
            "Hayam Wuruk Hotel and Convention menawarkan akomodasi di Trenggalek dan berjarak sejauh 1 km dari Stadion Menak Sopal Trenggalek. Properti ini memiliki Wi-Fi gratis.\n" +
                    "Setiap kamar dilengkapi dengan AC. Shower tersedia di kamar mandi.\n" +
                    "Tamu dapat menikmati makanan di Lamongan Coto by Cak Ji. Pilihan tempat makan lain juga tersedia di sekitar properti.\n" +
                    "Fasilitas lain yang tersedia di Hayam Wuruk Hotel and Convention adalah ruang pertemuan.\n" +
                    "Stasiun terdekat adalah Stasiun Kediri, 58.8 km dari properti. ",
            R.drawable.hayamwuruk
        ),
        HotelData(
            "Griya Wafira",
            40,
            4.5,
            "Terletak di Trenggalek, OYO 93525 Griya Wafira Trenggalek Syariah menawarkan akomodasi bintang 2 dengan balkon pribadi. Di hotel, semua kamar dilengkapi AC dan TV. Bandara terdekat adalah Bandara Abdul Rachman Saleh, 151 km dari OYO 93525 Griya Wafira Trenggalek Syariah. ",
            R.drawable.griyawafira
        ),
        HotelData(
            "Griya Anggrek",
            81,
            4.4,
            "Griya Anggrek homestay yang terletak di Jl. Moh Yamin Sawahan Sumber Gedong trenggalek, dengan total 21 kamar, memiliki beberapa fasilitas, antara lain - Parkir area - Waterheater - Wifi - Televisi - Laundry service dan masih banyak lainnya. Dekat dengan tempat wisata trenggalek, dan cocok untuk kebutuhan bisnis atau berlibur anda. ",
            R.drawable.griyaanggrek
        ),
        HotelData(
            "Karanggoso Indah Hotel",
            59,
            4.8,
            "Karanggoso Indah Hotel menawarkan akomodasi di Trenggalek dan berjarak sejauh 280 meter dari Pantai Karanggongso. Properti ini memiliki akses WiFi gratis. Setiap kamar dilengkapi dengan tempat tidur yang nyaman & AC. Shower tersedia di kamar mandi. Tamu dapat menikmati makanan di Della Seafood. Pilihan tempat makan lain juga tersedia di sekitar properti. Fasilitas lain yang tersedia di Karanggoso Indah Hotel adalah TV layar datar. Bandara terdekat adalah Bandar Udara Abdul Rachman Saleh, 161 km dari properti. ",
            R.drawable.karanggongsohotel
        ),
        HotelData(
            "Jaas Permai",
            32,
            4.7,
            "Hot ",
            R.drawable.hayamwuruk
        ),
        HotelData(
            "Jaas Permai",
            32,
            4.7,
            "Hot ",
            R.drawable.hayamwuruk
        )
    )
}