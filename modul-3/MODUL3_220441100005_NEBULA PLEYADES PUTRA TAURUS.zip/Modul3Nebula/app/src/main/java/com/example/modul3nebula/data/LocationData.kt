package com.example.modul3nebula

data class LocationData(
    val name: String,
    val description: String,
    val lokasi: String,
    val image: Int
)
