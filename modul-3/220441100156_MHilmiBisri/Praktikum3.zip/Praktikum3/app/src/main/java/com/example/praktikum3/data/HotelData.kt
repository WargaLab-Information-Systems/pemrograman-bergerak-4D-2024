package com.example.praktikum3.data

data class HotelData (
    val name: String,
    val description: String,
    val tempat: String,
    val image: Int

)