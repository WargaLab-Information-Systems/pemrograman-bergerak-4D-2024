package com.example.modultiga.data

data class LocationData(
    val name: String,
    val description: String,
    val lokasi: String,
    val detail: String,
    val image: Int
)
