package com.example.modul4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.modul4.adapter.PostAdapterRoom
import com.example.modul4.room.PostDatabase
import com.example.modul4.room.PostViewModel
import com.example.modul4.room.PostViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var postViewModel: PostViewModel
    private lateinit var postAdapterRoom: PostAdapterRoom
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val factory = PostViewModelFactory.getInstance(this)
        postViewModel = ViewModelProvider(this, factory)[PostViewModel::class.java]
        recyclerView = findViewById(R.id.rv_post)
        recyclerView.layoutManager = LinearLayoutManager(this)

        postViewModel.getAllPost().observe(this) { postData ->
            if (postData != null) {
                postAdapterRoom = PostAdapterRoom(postData)
                postAdapterRoom.setOnItemClickCallback(object : PostAdapterRoom.OnItemClickCallback {
                    override fun onItemClicked(data: PostDatabase) {
                        // Handle item click if necessary
                    }

                    override fun onMoreButtonClicked(data: PostDatabase) {
                        showDeleteConfirmationDialog(data)
                    }
                })
                recyclerView.adapter = postAdapterRoom
            }
        }
    }

    private fun showDeleteConfirmationDialog(post: PostDatabase) {
        SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
            .setTitleText("Ubah Postingan atau Hapus?")
            .setContentText("Pastikan Pilihan Anda Benar, Bila Tidak maka Data Akan Terubah/Hilang!")
            .setConfirmText("Hapus Postingan")
            .setCancelButtonBackgroundColor(R.color.white)
            .setConfirmClickListener { sDialog ->
                sDialog.dismissWithAnimation()
                deletePost(post)
            }
            .setCancelButton("Update Postingan") { sDialog ->
                sDialog.dismissWithAnimation()
                val intent = Intent(this, UpdateActivity::class.java)
                intent.putExtra("post", post)
                startActivity(intent)
            }
            .show()
    }

    private fun deletePost(post: PostDatabase) {
        postViewModel.deletePost(post)
        postAdapterRoom.notifyDataSetChanged()
    }

    fun toAddPost(view: View) {
        val intent = Intent(this, AddPostActivity::class.java)
        startActivity(intent)
    }

    override fun onRestart() {
        super.onRestart()
        postViewModel.getAllPost()
    }
}
