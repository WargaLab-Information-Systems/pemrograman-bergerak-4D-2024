package com.example.tugas2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Halaman_Profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_profile)
    }
}